"""
Training Script for Signature Detection Model
"""

import os
import numpy as np
import cv2
from sklearn.model_selection import train_test_split
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import matplotlib.pyplot as plt

class SignatureModelTrainer:
    """Train CNN model for signature detection"""
    
    def __init__(self, img_size=(128, 128)):
        self.img_size = img_size
        self.model = None
        self.history = None
    
    def load_data(self, data_folder):
        """Load and preprocess training data"""
        signatures = []
        non_signatures = []
        
        # Load signature samples
        signature_folder = os.path.join(data_folder, 'signatures')
        if os.path.exists(signature_folder):
            for img_file in os.listdir(signature_folder):
                img_path = os.path.join(signature_folder, img_file)
                img = cv2.imread(img_path, 0)
                img = cv2.resize(img, self.img_size)
                signatures.append(img)
        
        # Load non-signature samples
        non_signature_folder = os.path.join(data_folder, 'non_signatures')
        if os.path.exists(non_signature_folder):
            for img_file in os.listdir(non_signature_folder):
                img_path = os.path.join(non_signature_folder, img_file)
                img = cv2.imread(img_path, 0)
                img = cv2.resize(img, self.img_size)
                non_signatures.append(img)
        
        # Prepare dataset
        X = np.array(signatures + non_signatures)
        y = np.array([1] * len(signatures) + [0] * len(non_signatures))
        
        # Normalize
        X = X.astype('float32') / 255.0
        X = X.reshape(-1, self.img_size[0], self.img_size[1], 1)
        
        return train_test_split(X, y, test_size=0.2, random_state=42)
    
    def build_model(self):
        """Build CNN architecture"""
        model = keras.Sequential([
            # First Convolutional Block
            layers.Conv2D(32, (3, 3), activation='relu', 
                         input_shape=(self.img_size[0], self.img_size[1], 1)),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Second Convolutional Block
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Third Convolutional Block
            layers.Conv2D(128, (3, 3), activation='relu'),
            layers.BatchNormalization(),
            layers.MaxPooling2D((2, 2)),
            layers.Dropout(0.25),
            
            # Fully Connected Layers
            layers.Flatten(),
            layers.Dense(256, activation='relu'),
            layers.BatchNormalization(),
            layers.Dropout(0.5),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.5),
            
            # Output Layer
            layers.Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy', keras.metrics.Precision(), keras.metrics.Recall()]
        )
        
        self.model = model
        return model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=50, batch_size=32):
        """Train the model"""
        # Data augmentation
        datagen = ImageDataGenerator(
            rotation_range=10,
            width_shift_range=0.1,
            height_shift_range=0.1,
            zoom_range=0.1,
            horizontal_flip=False
        )
        
        # Callbacks
        callbacks = [
            keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=10,
                restore_best_weights=True
            ),
            keras.callbacks.ReduceLROnPlateau(
                monitor='val_loss',
                factor=0.5,
                patience=5,
                min_lr=1e-7
            ),
            keras.callbacks.ModelCheckpoint(
                'models/signature_detector_best.h5',
                save_best_only=True,
                monitor='val_accuracy'
            )
        ]
        
        # Train
        self.history = self.model.fit(
            datagen.flow(X_train, y_train, batch_size=batch_size),
            epochs=epochs,
            validation_data=(X_val, y_val),
            callbacks=callbacks,
            verbose=1
        )
        
        return self.history
    
    def evaluate(self, X_test, y_test):
        """Evaluate model performance"""
        loss, accuracy, precision, recall = self.model.evaluate(X_test, y_test)
        
        print("\n" + "=" * 50)
        print("Model Evaluation Results")
        print("=" * 50)
        print(f"Loss: {loss:.4f}")
        print(f"Accuracy: {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall: {recall:.4f}")
        print(f"F1-Score: {2 * (precision * recall) / (precision + recall):.4f}")
        
        return loss, accuracy, precision, recall
    
    def plot_training_history(self):
        """Plot training metrics"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Accuracy
        axes[0, 0].plot(self.history.history['accuracy'], label='Train')
        axes[0, 0].plot(self.history.history['val_accuracy'], label='Validation')
        axes[0, 0].set_title('Model Accuracy')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Accuracy')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        # Loss
        axes[0, 1].plot(self.history.history['loss'], label='Train')
        axes[0, 1].plot(self.history.history['val_loss'], label='Validation')
        axes[0, 1].set_title('Model Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        # Precision
        axes[1, 0].plot(self.history.history['precision'], label='Train')
        axes[1, 0].plot(self.history.history['val_precision'], label='Validation')
        axes[1, 0].set_title('Model Precision')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Precision')
        axes[1, 0].legend()
        axes[1, 0].grid(True)
        
        # Recall
        axes[1, 1].plot(self.history.history['recall'], label='Train')
        axes[1, 1].plot(self.history.history['val_recall'], label='Validation')
        axes[1, 1].set_title('Model Recall')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('Recall')
        axes[1, 1].legend()
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        plt.savefig('training_history.png', dpi=300, bbox_inches='tight')
        print("\nTraining plots saved to: training_history.png")
    
    def save_model(self, filepath='models/signature_detector.h5'):
        """Save trained model"""
        os.makedirs('models', exist_ok=True)
        self.model.save(filepath)
        print(f"\nModel saved to: {filepath}")
    
    def load_model(self, filepath='models/signature_detector.h5'):
        """Load pre-trained model"""
        self.model = keras.models.load_model(filepath)
        print(f"\nModel loaded from: {filepath}")
        return self.model


def generate_sample_data():
    """Generate sample training data"""
    print("Generating sample training data...")
    
    os.makedirs('data/training_data/signatures', exist_ok=True)
    os.makedirs('data/training_data/non_signatures', exist_ok=True)
    
    # Generate synthetic signature-like images
    for i in range(100):
        img = np.random.randint(200, 255, (128, 128), dtype=np.uint8)
        # Add some signature-like scribbles
        for _ in range(np.random.randint(3, 8)):
            x1, y1 = np.random.randint(0, 128, 2)
            x2, y2 = np.random.randint(0, 128, 2)
            cv2.line(img, (x1, y1), (x2, y2), 0, np.random.randint(1, 3))
        cv2.imwrite(f'data/training_data/signatures/sig_{i}.png', img)
    
    # Generate non-signature images (mostly text)
    for i in range(100):
        img = np.random.randint(200, 255, (128, 128), dtype=np.uint8)
        # Add some text-like patterns
        for _ in range(np.random.randint(5, 15)):
            x, y = np.random.randint(0, 100, 2)
            cv2.rectangle(img, (x, y), (x+20, y+5), 0, -1)
        cv2.imwrite(f'data/training_data/non_signatures/non_sig_{i}.png', img)
    
    print("Sample data generated successfully!")


# Main training pipeline
if __name__ == "__main__":
    print("=" * 50)
    print("Signature Detection Model Training")
    print("=" * 50)
    
    # Generate sample data (if needed)
    # generate_sample_data()
    
    # Initialize trainer
    trainer = SignatureModelTrainer()
    
    # Load data
    print("\nLoading training data...")
    X_train, X_test, y_train, y_test = trainer.load_data('data/training_data')
    print(f"Training samples: {len(X_train)}")
    print(f"Test samples: {len(X_test)}")
    
    # Build model
    print("\nBuilding model...")
    model = trainer.build_model()
    model.summary()
    
    # Train model
    print("\nTraining model...")
    trainer.train(X_train, y_train, X_test, y_test, epochs=30)
    
    # Evaluate
    print("\nEvaluating model...")
    trainer.evaluate(X_test, y_test)
    
    # Plot results
    trainer.plot_training_history()
    
    # Save model
    trainer.save_model()
    
    print("\n✅ Training completed successfully!")
