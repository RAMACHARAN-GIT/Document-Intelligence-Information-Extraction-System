"""
Document Intelligence & Information Extraction System
A complete end-to-end pipeline for extracting structured information from unstructured documents
"""

import os
import re
import json
import cv2
import numpy as np
import pandas as pd
from PIL import Image
import pytesseract
import spacy
from datetime import datetime
from typing import Dict, List, Tuple, Any

# Machine Learning imports
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

class DocumentProcessor:
    """Handles OCR and document parsing"""
    
    def __init__(self):
        self.supported_formats = ['.pdf', '.png', '.jpg', '.jpeg', '.tiff']
    
    def preprocess_image(self, image_path: str) -> np.ndarray:
        """Preprocess image for better OCR results"""
        # Read image
        img = cv2.imread(image_path)
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply thresholding to preprocess the image
        gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
        
        # Apply dilation and erosion to remove noise
        kernel = np.ones((1, 1), np.uint8)
        gray = cv2.dilate(gray, kernel, iterations=1)
        gray = cv2.erode(gray, kernel, iterations=1)
        
        return gray
    
    def extract_text_ocr(self, image_path: str) -> str:
        """Extract text from image using OCR"""
        try:
            # Preprocess image
            processed_img = self.preprocess_image(image_path)
            
            # Perform OCR
            text = pytesseract.image_to_string(processed_img, lang='eng')
            
            return text.strip()
        except Exception as e:
            print(f"Error in OCR: {str(e)}")
            return ""
    
    def extract_text_with_layout(self, image_path: str) -> Dict:
        """Extract text with layout information"""
        try:
            processed_img = self.preprocess_image(image_path)
            
            # Get detailed OCR data
            data = pytesseract.image_to_data(processed_img, output_type=pytesseract.Output.DICT)
            
            return data
        except Exception as e:
            print(f"Error in layout extraction: {str(e)}")
            return {}


class NLPProcessor:
    """Handles NLP tasks for entity extraction and text normalization"""
    
    def __init__(self):
        # Load spaCy model for NLP
        try:
            self.nlp = spacy.load('en_core_web_sm')
        except:
            print("Downloading spaCy model...")
            os.system('python -m spacy download en_core_web_sm')
            self.nlp = spacy.load('en_core_web_sm')
    
    def normalize_text(self, text: str) -> str:
        """Normalize text by removing extra spaces and standardizing format"""
        # Remove extra whitespaces
        text = ' '.join(text.split())
        
        # Remove special characters but keep alphanumeric and basic punctuation
        text = re.sub(r'[^\w\s\.\,\-\:\;\(\)]', '', text)
        
        return text.strip()
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract named entities from text"""
        doc = self.nlp(text)
        
        entities = {
            'PERSON': [],
            'ORG': [],
            'DATE': [],
            'MONEY': [],
            'GPE': [],  # Geopolitical entities
            'CARDINAL': [],  # Numbers
        }
        
        for ent in doc.ents:
            if ent.label_ in entities:
                entities[ent.label_].append(ent.text)
        
        return entities
    
    def extract_dates(self, text: str) -> List[str]:
        """Extract dates using regex patterns"""
        date_patterns = [
            r'\d{1,2}[-/]\d{1,2}[-/]\d{2,4}',  # DD/MM/YYYY or MM/DD/YYYY
            r'\d{4}[-/]\d{1,2}[-/]\d{1,2}',    # YYYY/MM/DD
            r'\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\b',
        ]
        
        dates = []
        for pattern in date_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            dates.extend(matches)
        
        return dates
    
    def extract_emails(self, text: str) -> List[str]:
        """Extract email addresses"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        return re.findall(email_pattern, text)
    
    def extract_phone_numbers(self, text: str) -> List[str]:
        """Extract phone numbers"""
        phone_patterns = [
            r'\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}',
            r'\d{10}',
        ]
        
        phones = []
        for pattern in phone_patterns:
            matches = re.findall(pattern, text)
            phones.extend(matches)
        
        return phones


class SignatureDetector:
    """Detects signatures in documents using neural networks"""
    
    def __init__(self):
        self.model = self.build_model()
        self.img_size = (128, 128)
    
    def build_model(self) -> keras.Model:
        """Build CNN model for signature detection"""
        model = keras.Sequential([
            layers.Conv2D(32, (3, 3), activation='relu', input_shape=(128, 128, 1)),
            layers.MaxPooling2D((2, 2)),
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.MaxPooling2D((2, 2)),
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.Flatten(),
            layers.Dense(64, activation='relu'),
            layers.Dropout(0.5),
            layers.Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        return model
    
    def detect_signature_regions(self, image_path: str) -> List[Tuple[int, int, int, int]]:
        """Detect potential signature regions in document"""
        img = cv2.imread(image_path, 0)
        
        # Apply thresholding
        _, thresh = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        signature_regions = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            # Filter based on signature-like dimensions
            if 50 < w < 300 and 20 < h < 100:
                signature_regions.append((x, y, w, h))
        
        return signature_regions


class EntityResolver:
    """Resolves entities and relationships"""
    
    def __init__(self):
        self.entity_database = {}
    
    def add_entity(self, entity_type: str, entity_value: str, metadata: Dict = None):
        """Add entity to database"""
        if entity_type not in self.entity_database:
            self.entity_database[entity_type] = []
        
        entity_entry = {
            'value': entity_value,
            'metadata': metadata or {},
            'timestamp': datetime.now().isoformat()
        }
        
        self.entity_database[entity_type].append(entity_entry)
    
    def resolve_entity(self, entity_type: str, entity_value: str) -> Dict:
        """Resolve entity from database"""
        if entity_type in self.entity_database:
            for entity in self.entity_database[entity_type]:
                if entity['value'].lower() == entity_value.lower():
                    return entity
        
        return None
    
    def find_relationships(self, entities: Dict) -> List[Dict]:
        """Find relationships between entities"""
        relationships = []
        
        # Example: Link persons to organizations
        if 'PERSON' in entities and 'ORG' in entities:
            for person in entities['PERSON']:
                for org in entities['ORG']:
                    relationships.append({
                        'type': 'person_org',
                        'person': person,
                        'organization': org
                    })
        
        return relationships


class DocumentIntelligenceSystem:
    """Main system orchestrating all components"""
    
    def __init__(self):
        self.doc_processor = DocumentProcessor()
        self.nlp_processor = NLPProcessor()
        self.signature_detector = SignatureDetector()
        self.entity_resolver = EntityResolver()
    
    def process_document(self, document_path: str) -> Dict[str, Any]:
        """Process a single document end-to-end"""
        print(f"Processing document: {document_path}")
        
        results = {
            'document_path': document_path,
            'processed_at': datetime.now().isoformat(),
            'raw_text': '',
            'normalized_text': '',
            'entities': {},
            'dates': [],
            'emails': [],
            'phone_numbers': [],
            'signature_regions': [],
            'relationships': []
        }
        
        # Step 1: OCR - Extract text
        print("Step 1: Extracting text using OCR...")
        raw_text = self.doc_processor.extract_text_ocr(document_path)
        results['raw_text'] = raw_text
        
        if not raw_text:
            print("No text extracted from document")
            return results
        
        # Step 2: Text Normalization
        print("Step 2: Normalizing text...")
        normalized_text = self.nlp_processor.normalize_text(raw_text)
        results['normalized_text'] = normalized_text
        
        # Step 3: Entity Extraction
        print("Step 3: Extracting entities...")
        entities = self.nlp_processor.extract_entities(normalized_text)
        results['entities'] = entities
        
        # Step 4: Extract specific information
        print("Step 4: Extracting dates, emails, phone numbers...")
        results['dates'] = self.nlp_processor.extract_dates(normalized_text)
        results['emails'] = self.nlp_processor.extract_emails(normalized_text)
        results['phone_numbers'] = self.nlp_processor.extract_phone_numbers(normalized_text)
        
        # Step 5: Signature Detection
        print("Step 5: Detecting signatures...")
        signature_regions = self.signature_detector.detect_signature_regions(document_path)
        results['signature_regions'] = signature_regions
        
        # Step 6: Entity Resolution
        print("Step 6: Resolving entities and finding relationships...")
        for entity_type, entity_values in entities.items():
            for value in entity_values:
                self.entity_resolver.add_entity(entity_type, value)
        
        relationships = self.entity_resolver.find_relationships(entities)
        results['relationships'] = relationships
        
        print("Document processing complete!")
        return results
    
    def process_batch(self, document_folder: str, output_file: str = 'results.json'):
        """Process multiple documents in a folder"""
        all_results = []
        
        for filename in os.listdir(document_folder):
            file_path = os.path.join(document_folder, filename)
            
            if os.path.isfile(file_path):
                ext = os.path.splitext(filename)[1].lower()
                if ext in self.doc_processor.supported_formats:
                    result = self.process_document(file_path)
                    all_results.append(result)
        
        # Save results to JSON
        with open(output_file, 'w') as f:
            json.dump(all_results, f, indent=2)
        
        print(f"\nProcessed {len(all_results)} documents. Results saved to {output_file}")
        return all_results
    
    def export_to_excel(self, results: List[Dict], output_file: str = 'extracted_data.xlsx'):
        """Export results to Excel for easy viewing"""
        data = []
        
        for result in results:
            row = {
                'Document': os.path.basename(result['document_path']),
                'Persons': ', '.join(result['entities'].get('PERSON', [])),
                'Organizations': ', '.join(result['entities'].get('ORG', [])),
                'Dates': ', '.join(result['dates']),
                'Emails': ', '.join(result['emails']),
                'Phone Numbers': ', '.join(result['phone_numbers']),
                'Signature Regions': len(result['signature_regions']),
            }
            data.append(row)
        
        df = pd.DataFrame(data)
        df.to_excel(output_file, index=False)
        print(f"Data exported to {output_file}")


# Example usage
if __name__ == "__main__":
    # Initialize system
    system = DocumentIntelligenceSystem()
    
    # Process single document
    # result = system.process_document('sample_document.jpg')
    
    # Process batch of documents
    # results = system.process_batch('documents_folder/')
    # system.export_to_excel(results)
    
    print("Document Intelligence System initialized successfully!")
    print("Use system.process_document(path) to process a single document")
    print("Use system.process_batch(folder) to process multiple documents")
