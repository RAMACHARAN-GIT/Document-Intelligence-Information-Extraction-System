"""
Sample Usage Examples for Document Intelligence System
"""

from document_intelligence_system import DocumentIntelligenceSystem
import json

def example_1_single_document():
    """Process a single document"""
    print("=" * 50)
    print("Example 1: Processing Single Document")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    
    # Process document
    result = system.process_document('sample_invoice.jpg')
    
    # Display results
    print("\n✓ Extracted Text (first 200 chars):")
    print(result['raw_text'][:200])
    
    print("\n✓ Entities Found:")
    for entity_type, values in result['entities'].items():
        if values:
            print(f"  {entity_type}: {', '.join(values[:3])}")
    
    print("\n✓ Contact Information:")
    print(f"  Emails: {result['emails']}")
    print(f"  Phone Numbers: {result['phone_numbers']}")
    
    print("\n✓ Dates Found:")
    print(f"  {result['dates']}")
    
    print("\n✓ Signature Regions:")
    print(f"  {len(result['signature_regions'])} signature(s) detected")


def example_2_batch_processing():
    """Process multiple documents"""
    print("\n" + "=" * 50)
    print("Example 2: Batch Processing")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    
    # Process all documents in folder
    results = system.process_batch('documents/', output_file='batch_results.json')
    
    print(f"\n✓ Processed {len(results)} documents")
    print(f"✓ Results saved to batch_results.json")
    
    # Export to Excel
    system.export_to_excel(results, 'batch_results.xlsx')
    print(f"✓ Excel export saved to batch_results.xlsx")


def example_3_custom_entity_extraction():
    """Custom entity extraction workflow"""
    print("\n" + "=" * 50)
    print("Example 3: Custom Entity Extraction")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    
    # Sample text
    sample_text = """
    Invoice #12345
    Date: March 20, 2024
    
    From: ABC Corporation
    123 Business Street
    New York, NY 10001
    
    To: John Doe
    john.doe@example.com
    Phone: +1-555-123-4567
    
    Total Amount: $1,250.00
    """
    
    # Normalize text
    normalized = system.nlp_processor.normalize_text(sample_text)
    print("\n✓ Normalized Text:")
    print(normalized)
    
    # Extract entities
    entities = system.nlp_processor.extract_entities(normalized)
    print("\n✓ Entities:")
    for entity_type, values in entities.items():
        if values:
            print(f"  {entity_type}: {values}")
    
    # Extract specific information
    emails = system.nlp_processor.extract_emails(sample_text)
    phones = system.nlp_processor.extract_phone_numbers(sample_text)
    dates = system.nlp_processor.extract_dates(sample_text)
    
    print("\n✓ Contact Details:")
    print(f"  Emails: {emails}")
    print(f"  Phones: {phones}")
    print(f"  Dates: {dates}")


def example_4_signature_detection():
    """Signature detection example"""
    print("\n" + "=" * 50)
    print("Example 4: Signature Detection")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    
    # Detect signatures
    regions = system.signature_detector.detect_signature_regions('contract.jpg')
    
    print(f"\n✓ Found {len(regions)} potential signature region(s)")
    
    for i, (x, y, w, h) in enumerate(regions, 1):
        print(f"  Signature {i}: Position({x}, {y}), Size({w}x{h})")


def example_5_entity_resolution():
    """Entity resolution and relationship mapping"""
    print("\n" + "=" * 50)
    print("Example 5: Entity Resolution & Relationships")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    
    # Sample entities
    entities = {
        'PERSON': ['John Doe', 'Jane Smith'],
        'ORG': ['ABC Corporation', 'XYZ Ltd'],
        'DATE': ['2024-03-20']
    }
    
    # Add entities to resolver
    for entity_type, values in entities.items():
        for value in values:
            system.entity_resolver.add_entity(entity_type, value)
    
    # Find relationships
    relationships = system.entity_resolver.find_relationships(entities)
    
    print("\n✓ Entity Relationships:")
    for rel in relationships:
        print(f"  {rel['person']} ↔ {rel['organization']}")


def example_6_performance_metrics():
    """Calculate processing performance"""
    print("\n" + "=" * 50)
    print("Example 6: Performance Metrics")
    print("=" * 50)
    
    import time
    
    system = DocumentIntelligenceSystem()
    
    # Measure processing time
    start_time = time.time()
    result = system.process_document('sample_document.jpg')
    end_time = time.time()
    
    processing_time = end_time - start_time
    
    print(f"\n✓ Processing Time: {processing_time:.2f} seconds")
    print(f"✓ Text Length: {len(result['raw_text'])} characters")
    print(f"✓ Entities Extracted: {sum(len(v) for v in result['entities'].values())}")
    print(f"✓ Processing Speed: {len(result['raw_text']) / processing_time:.0f} chars/sec")


def example_7_export_formats():
    """Different export formats"""
    print("\n" + "=" * 50)
    print("Example 7: Export to Different Formats")
    print("=" * 50)
    
    system = DocumentIntelligenceSystem()
    result = system.process_document('document.jpg')
    
    # Export to JSON
    with open('result.json', 'w') as f:
        json.dump(result, f, indent=2)
    print("✓ Exported to JSON: result.json")
    
    # Export to CSV
    import csv
    with open('result.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['Entity Type', 'Values'])
        for entity_type, values in result['entities'].items():
            writer.writerow([entity_type, ', '.join(values)])
    print("✓ Exported to CSV: result.csv")
    
    # Export to text
    with open('result.txt', 'w') as f:
        f.write("EXTRACTED TEXT\n")
        f.write("=" * 50 + "\n")
        f.write(result['normalized_text'])
    print("✓ Exported to TXT: result.txt")


if __name__ == "__main__":
    print("\n" + "🚀 Document Intelligence System - Usage Examples\n")
    
    # Run examples (comment out examples you don't want to run)
    
    try:
        # example_1_single_document()
        # example_2_batch_processing()
        example_3_custom_entity_extraction()
        # example_4_signature_detection()
        example_5_entity_resolution()
        # example_6_performance_metrics()
        # example_7_export_formats()
        
        print("\n✅ Examples completed successfully!")
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        print("Make sure you have sample documents in the correct paths")
